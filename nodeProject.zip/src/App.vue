<template>
  <div id="app" class="mainindex">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app',
  data(){
  	return{
  		
  	}
  }
}
</script>
<style lang="scss">
#app{
  height: 100%;
}
</style>
