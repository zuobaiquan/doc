# mymall

## 本项目分为四个模块
### 首页
### 分类
### 订单
### 个人中心

#### 页面效果如下：
#### 1.首页
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/1.png)

#### 2.详情页面
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/2.png)

#### 3.订单提交
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/3.png)

#### 4.提示页面
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/4.png)

#### 5.分类页面
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/5.png)

#### 6.具体分类
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/6.png)

#### 7.购物车页面
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/7.png)

#### 8.个人中心
![image](https://github.com/oohlxoo/mymall/raw/master/static/mymallpic/8.png)
